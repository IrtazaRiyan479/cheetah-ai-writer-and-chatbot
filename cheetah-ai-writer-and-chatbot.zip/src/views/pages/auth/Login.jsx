'use client'

// React Imports
import { useState, useEffect } from 'react'

// Next Imports
import Link from 'next/link'
import { useParams, useRouter } from 'next/navigation' // Added useRouter

// NextAuth Imports
import { signIn } from 'next-auth/react' // ADDED NEXT-AUTH

// MUI Imports
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import Typography from '@mui/material/Typography'
import TextField from '@mui/material/TextField'
import IconButton from '@mui/material/IconButton'
import InputAdornment from '@mui/material/InputAdornment'
import Checkbox from '@mui/material/Checkbox'
import Button from '@mui/material/Button'
import FormControlLabel from '@mui/material/FormControlLabel'
import Divider from '@mui/material/Divider'
import Alert from '@mui/material/Alert'
import CircularProgress from '@mui/material/CircularProgress'
import { useSession } from 'next-auth/react'

// Component Imports
import Logo from '@components/layout/shared/Logo'

// Hook Imports
import { useImageVariant } from '@core/hooks/useImageVariant'

// Util Imports
import { getLocalizedUrl } from '@/utils/i18n'

const Login = ({ mode }) => {
  const { status } = useSession()
  // UI States
  const [isPasswordShown, setIsPasswordShown] = useState(false)
  const [error, setError] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  // Form States
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [rememberMe, setRememberMe] = useState(false)

  // Vars
  const darkImg = '/images/pages/auth-v1-mask-1-dark.png'
  const lightImg = '/images/pages/auth-v1-mask-1-light.png'

  // Hooks
  const { lang: locale } = useParams()
  const router = useRouter()
  const authBackground = useImageVariant(mode, lightImg, darkImg)

  useEffect(() => {
    if (status === 'authenticated') {
      router.replace('/account')
    }
  }, [status, router])

  const handleClickShowPassword = () => setIsPasswordShown(show => !show)

  const isValidEmail = value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim())

  const handleSubmit = async e => {
    e.preventDefault()
    setError('')
    const trimmedEmail = email.trim()
    if (!isValidEmail(trimmedEmail)) {
      setError('Enter a valid email address (example: name@company.com).')
      return
    }
    if (!password) {
      setError('Enter your password.')
      return
    }
    setIsLoading(true)
    const res = await signIn('credentials', {
      redirect: false,
      email: trimmedEmail,
      password,
      remember: rememberMe ? 'true' : 'false'
    })
    if (res?.error) {
      setError('Email or password is incorrect.')
      setIsLoading(false)
    } else {
      router.push(getLocalizedUrl('/account', locale))
    }
  }

  const handleGoogleLogin = () => {
    signIn('google', { callbackUrl: getLocalizedUrl('/account', locale) })
  }

  return (
    <div className='flex flex-col justify-center items-center min-bs-[100dvh] relative p-6'>
      <Card className='flex flex-col sm:is-[450px]'>
        <CardContent className='p-6 sm:!p-12'>
          <Link href={getLocalizedUrl('/', locale)} className='flex justify-center items-center mbe-6'>
            <Logo />
          </Link>
          <div className='flex flex-col gap-5'>
            <div>
              <Typography variant='h4'>Welcome to AffiGenie! 👋🏻</Typography>
              <Typography className='mbs-1'>Please sign-in to your account and start the adventure</Typography>
            </div>

            {/* Display Error Message */}
            {error && <Alert severity="error">{error}</Alert>}

            <form noValidate autoComplete='off' onSubmit={handleSubmit} className='flex flex-col gap-5'>
              <TextField
                autoFocus
                fullWidth
                label='Email'
                type='email'
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <TextField
                fullWidth
                label='Password'
                required
                type={isPasswordShown ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position='end'>
                      <IconButton
                        size='small'
                        edge='end'
                        onClick={handleClickShowPassword}
                        onMouseDown={e => e.preventDefault()}
                      >
                        <i className={isPasswordShown ? 'ri-eye-off-line' : 'ri-eye-line'} />
                      </IconButton>
                    </InputAdornment>
                  )
                }}
              />
              <div className='flex justify-between items-center gap-x-3 gap-y-1 flex-wrap'>
                <FormControlLabel control={<Checkbox checked={rememberMe} onChange={e => setRememberMe(e.target.checked)} />} label='Remember Me' />
                <Typography className='text-end' color='primary' component={Link} href='/pages/misc/under-maintenance'>
                  Forgot password?
                </Typography>
              </div>
              <Button fullWidth variant='contained' type='submit' disabled={isLoading}>
                {isLoading ? <CircularProgress size={24} color="inherit" /> : 'Log In'}
              </Button>
              <div className='flex justify-center items-center flex-wrap gap-2'>
                <Typography>New on our platform?</Typography>
                <Typography
                  component={Link}
                  href={getLocalizedUrl('/register', locale)}
                  color='primary.main'
                >
                  Create an account
                </Typography>
              </div>
              <Divider className='gap-3'>or</Divider>
              <Button
                color='secondary'
                className='self-center text-textPrimary'
                type='button'
                startIcon={<img src='/images/logos/google.png' alt='Google' width={22} />}
                sx={{ '& .MuiButton-startIcon': { marginInlineEnd: 3 } }}
                onClick={handleGoogleLogin}
              >
                Sign in with Google
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>
      <img src={authBackground} className='absolute bottom-[5%] z-[-1] is-full max-md:hidden' />
    </div>
  )
}

export default Login
