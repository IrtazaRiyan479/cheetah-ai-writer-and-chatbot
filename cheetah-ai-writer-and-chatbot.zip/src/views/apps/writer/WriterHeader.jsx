'use client'

import { useEffect, useRef, useState } from 'react'

import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import Grid from '@mui/material/Grid'
import MenuItem from '@mui/material/MenuItem'
import Typography from '@mui/material/Typography'
import FormControl from '@mui/material/FormControl'
import Select from '@mui/material/Select'
import Button from '@mui/material/Button'
import Tooltip from '@mui/material/Tooltip'
import IconButton from '@mui/material/IconButton'
import Dialog from '@mui/material/Dialog'
import DialogTitle from '@mui/material/DialogTitle'
import DialogContent from '@mui/material/DialogContent'
import DialogActions from '@mui/material/DialogActions'
import DialogContentText from '@mui/material/DialogContentText'
import TextField from '@mui/material/TextField'

import { featureKeyForModel } from '@/libs/entitlement'

import { ProLabel, useFeatureAccess } from './FeatureAccessContext'

const FREE_DEFAULT_MODEL = 'gemini-3.1-flash-lite'
const PRO_DEFAULT_MODEL = 'claude-sonnet-5-5'

const availableModels = [
  { label: 'Gemini 3.1 Flash-Lite', value: 'gemini-3.1-flash-lite' },
  { label: 'Gemini 3.5 Flash', value: 'gemini-3.5-flash' },
  { label: 'Gemini 3.1 Pro', value: 'gemini-3.1-pro-preview-customtools' },
  { label: 'Claude Haiku 4.5', value: 'claude-haiku-4-5' },
  { label: 'Claude Haiku 5.5', value: 'claude-haiku-5-5' },
  { label: 'Claude Sonnet 4.5', value: 'claude-sonnet-4-5' },
  { label: 'Claude Sonnet 4.6', value: 'claude-sonnet-4-6' },
  { label: 'Claude Sonnet 5', value: 'claude-sonnet-5' },
  { label: 'Claude Sonnet 5.5', value: 'claude-sonnet-5-5' },
  { label: 'Claude Opus 4.6', value: 'claude-opus-4-6' },
  { label: 'Claude Opus 5.5', value: 'claude-opus-5-5' },
  { label: 'GPT-5.2', value: 'gpt-5.2' },
  { label: 'GPT-5 Mini', value: 'gpt-5-mini' },
  { label: 'Grok 4.7', value: 'grok-4.7' }
]

const WriterHeader = ({
  settings, updateSetting, presets, selectedPresetId,
  onLoadPreset, onCreatePreset, onUpdatePreset, onDeletePreset
}) => {
  const { requireFeature, modeOf, featureModes, isPaid, modesReady } = useFeatureAccess()
  const [openCreate, setOpenCreate] = useState(false)
  const [openDelete, setOpenDelete] = useState(false)
  const [newPresetName, setNewPresetName] = useState('')
  const planDefaultApplied = useRef(false)
  const models = availableModels.filter(model => modeOf(featureKeyForModel(model.value)) !== 'off')

  useEffect(() => {
    if (settings.model === 'claude-4.5-sonnet') {
      updateSetting('model', 'claude-sonnet-4-5')
      return
    }

    if (!models.length) return

    const currentAllowed = models.some(model => model.value === settings.model)

    if (!currentAllowed) {
      const fallback = models.some(model => model.value === FREE_DEFAULT_MODEL)
        ? FREE_DEFAULT_MODEL
        : models[0].value

      updateSetting('model', fallback)
      return
    }

    if (!modesReady || planDefaultApplied.current || selectedPresetId !== 'default') return
    if (settings.model !== FREE_DEFAULT_MODEL) {
      planDefaultApplied.current = true
      return
    }
    if (!isPaid) return

    planDefaultApplied.current = true
    const claudeDefault = models.some(model => model.value === PRO_DEFAULT_MODEL)
      ? PRO_DEFAULT_MODEL
      : models.find(model => model.value.startsWith('claude-'))?.value

    if (claudeDefault) updateSetting('model', claudeDefault)
  }, [featureModes, modesReady, isPaid, selectedPresetId])

  const handleModelChange = (e) => {
    const val = e.target.value
    if (!requireFeature(featureKeyForModel(val))) return
    updateSetting('model', val)
  }

  const submitCreate = () => {
    if (newPresetName.trim()) {
      onCreatePreset(newPresetName)
      setNewPresetName('')
      setOpenCreate(false)
    }
  }

  const submitDelete = () => {
    onDeletePreset()
    setOpenDelete(false)
  }

  return (
    <>
      <Card className='shadow-sm'>
        <CardContent className='p-4 sm:p-6'>
          <Grid container spacing={5} alignItems='flex-end'>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant='subtitle2' className='mbe-2 font-medium'>AI Model <Tooltip title='Uses the selected provider. Keys rotate on quota. If that provider is still rate limited, Groq then Mistral are used.'><i className='ri-information-line' /></Tooltip></Typography>
              <FormControl fullWidth size='small'>
                <Select value={models.some(model => model.value === settings.model) ? settings.model : (models[0]?.value || '')} onChange={handleModelChange}>
                  {models.map((model) => (
                    <MenuItem key={model.value} value={model.value}>
                      <ProLabel featureKey={featureKeyForModel(model.value)}>{model.label}</ProLabel>
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant='subtitle2' className='mbe-2 font-medium'>Project / Preset</Typography>
              <div className='flex items-center gap-2'>
                <FormControl fullWidth size='small'>
                  <Select value={selectedPresetId} onChange={(e) => onLoadPreset(e.target.value)}>
                    <MenuItem value='default'>Default Settings</MenuItem>
                    {presets.map(p => (
                      <MenuItem key={p.id} value={p.id}>{p.name}</MenuItem>
                    ))}
                  </Select>
                </FormControl>

                {/* The Action Buttons */}
                <Tooltip title='Create New Preset'>
                  <IconButton onClick={() => setOpenCreate(true)} color='primary' className='bg-primary/10 rounded'>
                    <i className='ri-add-line' />
                  </IconButton>
                </Tooltip>
                <Tooltip title='Save Current State'>
                  <IconButton onClick={onUpdatePreset} disabled={selectedPresetId === 'default'} color='success' className='bg-success/10 rounded disabled:opacity-50'>
                    <i className='ri-save-line' />
                  </IconButton>
                </Tooltip>
                <Tooltip title='Delete Preset'>
                  <IconButton onClick={() => setOpenDelete(true)} disabled={selectedPresetId === 'default'} color='error' className='bg-error/10 rounded disabled:opacity-50'>
                    <i className='ri-delete-bin-7-line' />
                  </IconButton>
                </Tooltip>
              </div>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* CREATE PRESET DIALOG */}
      <Dialog open={openCreate} onClose={() => setOpenCreate(false)} fullWidth maxWidth="xs">
        <DialogTitle>Create New Preset</DialogTitle>
        <DialogContent>
          <DialogContentText className='mbe-3'>
            Enter a name for your preset. This will save all your current settings and toggles.
          </DialogContentText>
          <TextField
            autoFocus fullWidth size="small" label='Preset Name'
            value={newPresetName} onChange={e => setNewPresetName(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenCreate(false)} color='secondary'>Cancel</Button>
          <Button onClick={submitCreate} variant='contained' disabled={!newPresetName.trim()}>Save Preset</Button>
        </DialogActions>
      </Dialog>

      {/* DELETE PRESET DIALOG */}
      <Dialog open={openDelete} onClose={() => setOpenDelete(false)}>
        <DialogTitle>Delete Preset?</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete this preset? This action cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDelete(false)} color='secondary'>Cancel</Button>
          <Button onClick={submitDelete} variant='contained' color='error'>Delete</Button>
        </DialogActions>
      </Dialog>
    </>
  )
}

export default WriterHeader
