'use client'

import { useCallback, useEffect, useState } from 'react'

import Box from '@mui/material/Box'
import CircularProgress from '@mui/material/CircularProgress'
import LinearProgress from '@mui/material/LinearProgress'
import Typography from '@mui/material/Typography'
import { useMediaQuery } from '@mui/material'
import { toast } from 'react-toastify'

import { useDispatch, useSelector } from 'react-redux'

import Calendar from './Calendar'
import SidebarLeft from './SidebarLeft'
import AddEventSidebar from './AddEventSidebar'

import { setEvents } from '@/redux-store/slices/calendar'

import AppFullCalendar from '@/libs/styles/AppFullCalendar'

const calendarsColor = {
  Draft: 'warning',
  Published: 'success',
  Scheduled: 'primary'
}

const recentWarnings = new Map()

function toastWarningOnce(message) {
  const text = String(message || '').trim()

  if (!text) return

  const now = Date.now()

  if (now - (recentWarnings.get(text) || 0) < 8000) return

  recentWarnings.set(text, now)
  toast.error(text)
}

async function persist(kind, payload) {
  if (kind === 'delete') {
    const res = await fetch(`/api/calendar?id=${encodeURIComponent(payload.id)}`, { method: 'DELETE' })
    const data = await res.json().catch(() => ({}))

    if (!res.ok) throw new Error(data.error || 'Could not remove this article from the calendar.')

    return data
  }

  const res = await fetch('/api/calendar', {
    method: kind === 'create' ? 'POST' : 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  const data = await res.json().catch(() => ({}))

  if (!res.ok) throw new Error(data.error || 'Could not save this article.')

  return data.event
}

const AppCalendar = () => {
  const [calendarApi, setCalendarApi] = useState(null)
  const [leftSidebarOpen, setLeftSidebarOpen] = useState(false)
  const [addEventSidebarOpen, setAddEventSidebarOpen] = useState(false)
  const [siteOptions, setSiteOptions] = useState([])
  const [selectedSites, setSelectedSites] = useState(null)
  const [drafts, setDrafts] = useState([])
  const [sitesLoaded, setSitesLoaded] = useState(false)
  const [loading, setLoading] = useState(true)

  const dispatch = useDispatch()
  const calendarStore = useSelector(state => state.calendarReducer)
  const mdAbove = useMediaQuery(theme => theme.breakpoints.up('md'))
  const handleLeftSidebarToggle = () => setLeftSidebarOpen(!leftSidebarOpen)
  const handleAddEventSidebarToggle = () => setAddEventSidebarOpen(!addEventSidebarOpen)

  const loadEvents = useCallback(async () => {
    setLoading(true)

    try {
      const res = await fetch('/api/calendar', { cache: 'no-store' })
      const data = await res.json().catch(() => ({}))

      if (!res.ok || data.error) {
        toast.error(data.error || 'Could not load the publishing calendar.')

        return
      }

      if (Array.isArray(data.events)) dispatch(setEvents(data.events))
      if (Array.isArray(data.warnings) && data.warnings.length) {
        data.warnings.forEach(message => toastWarningOnce(message))
      }

      setDrafts(Array.isArray(data.drafts) ? data.drafts : [])
      setSiteOptions(Array.isArray(data.sites) ? data.sites : [])
    } catch {
      toast.error('Could not load the publishing calendar.')
    } finally {
      setSitesLoaded(true)
      setLoading(false)
    }
  }, [dispatch])

  useEffect(() => {
    loadEvents()
  }, [loadEvents])

  useEffect(() => {
    const main = document.querySelector('main.ts-vertical-layout-content')

    if (!main) return undefined

    const previous = {
      maxInlineSize: main.style.maxInlineSize,
      marginInline: main.style.marginInline,
      width: main.style.width
    }

    main.style.maxInlineSize = 'none'
    main.style.marginInline = '0'
    main.style.width = '100%'

    const frame = window.requestAnimationFrame(() => calendarApi?.updateSize())

    return () => {
      window.cancelAnimationFrame(frame)
      main.style.maxInlineSize = previous.maxInlineSize
      main.style.marginInline = previous.marginInline
      main.style.width = previous.width
    }
  }, [calendarApi])

  useEffect(() => {
    if (!sitesLoaded) return

    const keys = siteOptions.map(site => site.value)

    setSelectedSites(prev => (prev == null ? keys : prev.filter(key => keys.includes(key))))
  }, [siteOptions, sitesLoaded])

  const toggleSite = key => {
    setSelectedSites(prev => {
      const base = prev == null ? siteOptions.map(site => site.value) : prev

      return base.includes(key) ? base.filter(item => item !== key) : [...base, key]
    })
  }

  const toggleAllSites = checked => {
    setSelectedSites(checked ? siteOptions.map(site => site.value) : [])
  }

  const siteKeySet = new Set(siteOptions.map(site => site.value))
  const events = (calendarStore.events || []).filter(event => {
    if (!siteOptions.length || selectedSites == null) return true

    const siteKey = String(event?.extendedProps?.siteKey || '').trim()
    const match = siteOptions.find(site => site.value === siteKey || site.label === siteKey)

    if (match) return selectedSites.includes(match.value)

    // Articles with no saved website follow View All. A partial site selection hides them.
    return selectedSites.length === siteOptions.length && selectedSites.every(key => siteKeySet.has(key))
  })

  const onPersist = async (kind, payload) => {
    try {
      const event = await persist(kind, payload)

      if (kind === 'delete') {
        loadEvents()

        return event
      }

      await loadEvents()

      return event
    } catch (error) {
      toast.error(error.message || 'Calendar save failed.')

      return null
    }
  }

  return (
    <AppFullCalendar className='app-calendar'>
      <SidebarLeft
        mdAbove={mdAbove}
        dispatch={dispatch}
        calendarApi={calendarApi}
        calendarStore={calendarStore}
        calendarsColor={calendarsColor}
        leftSidebarOpen={leftSidebarOpen}
        handleLeftSidebarToggle={handleLeftSidebarToggle}
        handleAddEventSidebarToggle={handleAddEventSidebarToggle}
        siteOptions={siteOptions}
        selectedSites={selectedSites}
        sitesLoading={!sitesLoaded}
        onToggleSite={toggleSite}
        onToggleAllSites={toggleAllSites}
      />
      <div className='p-5 pbe-0 grow overflow-visible bg-backgroundPaper rounded is-full min-is-0' style={{ position: 'relative' }}>
        {loading && !sitesLoaded ? (
          <Box
            sx={{
              position: 'absolute',
              inset: 0,
              zIndex: 5,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 2,
              borderRadius: 1,
              bgcolor: theme => (theme.palette.mode === 'dark' ? 'rgba(0,0,0,0.55)' : 'rgba(255,255,255,0.82)')
            }}
          >
            <CircularProgress size={28} />
            <Typography variant='body2' color='text.secondary'>
              Loading articles and websites…
            </Typography>
          </Box>
        ) : null}
        {loading && sitesLoaded ? (
          <LinearProgress sx={{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 5 }} />
        ) : null}
        <Calendar
          dispatch={dispatch}
          calendarApi={calendarApi}
          calendarStore={calendarStore}
          setCalendarApi={setCalendarApi}
          calendarsColor={calendarsColor}
          handleLeftSidebarToggle={handleLeftSidebarToggle}
          handleAddEventSidebarToggle={handleAddEventSidebarToggle}
          onPersist={onPersist}
          onReload={loadEvents}
          events={events}
        />
      </div>
      <AddEventSidebar
        dispatch={dispatch}
        calendarApi={calendarApi}
        calendarStore={calendarStore}
        addEventSidebarOpen={addEventSidebarOpen}
        handleAddEventSidebarToggle={handleAddEventSidebarToggle}
        onPersist={onPersist}
        onReload={loadEvents}
        siteOptions={siteOptions}
        drafts={drafts}
      />
    </AppFullCalendar>
  )
}

export default AppCalendar
