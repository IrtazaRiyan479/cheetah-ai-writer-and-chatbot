import {
  getLinkInstruction,
  getExternalLinkInstruction,
  getReadabilityInstruction,
  getSeoInstruction,
  getPovInstruction,
  getToneInstruction,
  getBaseSystemInstruction,
  fetchUnsplashImage,
  fetchPexelsImage,
  fetchPixabayImage,
  calculateRelevanceScore,
  fetchPeopleAlsoSearchFor,
  generateFallbackImage,
  fetchSerperOutlineData
} from '../utils/helpers'
import { languages } from '@/configs/languages'
import { countries } from '@/configs/countries'
import { callLightLLM, parseJsonSafe } from '../utils/lightLLM'
import {
  buildCheckPriceButton,
  cleanRewriteKeyword,
  escapeHtml,
  renderResponsiveTable,
  renderTopPickCards,
  resolveAffiliateUrl,
  titleCaseWords,
  withRequiredCheckPrice
} from '../utils/articleHtml'

export async function fetchInternalAmazonData(keyword, settings) {
  const baseUrl =
    process.env.NEXT_PUBLIC_APP_URL ||
    (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : 'http://localhost:3000')

  let lastError = null

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const response = await fetch(`${baseUrl}/api/amazon`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          keyword: keyword,
          asins: Array.isArray(settings.asins) ? settings.asins : undefined,
          domain: settings.amazonDomain || 'www.amazon.com',
          partnerTag: process.env.AMAZON_PARTNER_TAG
        }),
        signal: AbortSignal.timeout(45000)
      })

      if (!response.ok) {
        const errorText = await response.text()
        let errorDetails = errorText

        try {
          const parsed = JSON.parse(errorText)

          errorDetails = parsed.details ? JSON.stringify(parsed.details) : parsed.error || errorText
        } catch (e) {}

        const message = String(errorDetails || '')

        lastError = new Error(`Amazon API ${response.status}: ${message.slice(0, 300)}`)

        if (
          response.status >= 500 ||
          response.status === 429 ||
          /timeout|fetch failed|credits|throttl/i.test(message)
        ) {
          console.warn(`[amazon] attempt ${attempt}/3 failed:`, message.slice(0, 180))
          await new Promise(r => setTimeout(r, 800 * attempt))
          continue
        }

        console.error('Amazon Route Failed:', errorDetails)
        throw lastError
      }

      return await response.json()
    } catch (error) {
      lastError = error
      const msg = String(error?.message || error)

      if (/timeout|abort|fetch failed|ECONN|network/i.test(msg) && attempt < 3) {
        console.warn(`[amazon] network attempt ${attempt}/3:`, msg.slice(0, 180))
        await new Promise(r => setTimeout(r, 800 * attempt))
        continue
      }

      if (attempt >= 3) break
      throw error
    }
  }

  throw lastError || new Error('Amazon API failed after retries.')
}

export function toHdAmazonImage(url) {
  let raw = String(url || '').trim()

  if (!raw) return ''
  if (!/(?:m\.media-amazon\.com|images-amazon\.com|ssl-images-amazon\.com)/i.test(raw)) return raw

  raw = raw.split('?')[0]

  if (/%5FAC%5FSL1500%5F|\._AC_SL1500_\./i.test(raw)) {
    return raw.replace(/_/g, '%5F')
  }

  const base = raw.replace(/\._[^/?#]+(?=\.(?:jpe?g|png|webp)$)/i, '')

  return base.replace(/\.(jpe?g|png|webp)$/i, '.%5FAC%5FSL1500%5F.$1')
}

export function formatAmazonProducts(apiData, settings) {
  const rawData = apiData?.data?.searchResult?.items || []
  const numberOfProducts = settings.numberOfProducts || 5
  const limitedProducts = rawData.slice(0, numberOfProducts)

  const domain = settings.amazonDomain || 'www.amazon.com'
  const partnerTag = process.env.AMAZON_PARTNER_TAG || ''

  return limitedProducts.map(item => {
    const title = item?.itemInfo?.title?.displayValue || 'Amazon Product'
    const asin = item?.asin || ''
    const imageUrl = toHdAmazonImage(item?.images?.primary?.large?.url || item?.images?.primary?.medium?.url || '')
    const price = item?.offersV2?.listings?.[0]?.price?.money?.displayAmount || 'See listing'
    const features = item?.itemInfo?.features?.displayValues || []

    return {
      productName: title,
      asin,
      amazonUrl: resolveAffiliateUrl({
        url: item?.detailPageURL,
        asin,
        domain,
        partnerTag,
        forceTag: settings.amazonTrackingId || ''
      }),
      imageUrl: imageUrl,
      price: price,
      rating: item?.customerReviews?.starRating || item?.customerReviews?.rating || null,
      features: features
    }
  })
}

async function fillRoundupProducts(products, settings, keyword) {
  const requested = Math.max(1, Math.min(10, Number(settings.numberOfProducts) || products.length || 5))
  const kept = []
  const seen = new Set()

  for (const product of products) {
    if (kept.length >= requested) break
    const asin = String(product?.asin || '').toUpperCase()

    if (asin && seen.has(asin)) continue
    if (asin) seen.add(asin)
    kept.push(product)
  }

  if (kept.length < requested && keyword) {
    try {
      const apiData = await fetchInternalAmazonData(keyword, { ...settings, asins: undefined, numberOfProducts: 10 })
      const searched = formatAmazonProducts(apiData, { ...settings, numberOfProducts: 10 })

      for (const product of searched) {
        if (kept.length >= requested) break
        const asin = String(product?.asin || '').toUpperCase()

        if (asin && seen.has(asin)) continue
        if (asin) seen.add(asin)
        kept.push(product)
      }
    } catch (error) {
      console.warn('[amazon-roundup-rewrite] product fill failed:', error?.message || error)
    }
  }

  return kept.slice(0, requested)
}

function outlineProductData(product) {
  const features = (Array.isArray(product?.features) ? product.features : [])
    .map(item => String(item || '').replace(/\s+/g, ' ').trim())
    .filter(Boolean)
    .slice(0, 3)
    .map(item => item.slice(0, 180))

  return {
    productName: product?.productName || '',
    amazonUrl: product?.amazonUrl || '',
    imageUrl: product?.imageUrl || '',
    price: product?.price || '',
    asin: product?.asin || '',
    rating: product?.rating || '',
    features
  }
}

function applyExactProductOutline(outline, products) {
  const items = Array.isArray(outline) ? outline : []

  const productItems = products.map((product, index) => ({
    type: 'h2',
    text: titleCaseWords(`${index + 1}. ${product.productName || product.asin || 'Amazon Product'}`),
    sectionType: 'product',
    productData: outlineProductData(product)
  }))

  const before = []
  const after = []
  let seenProduct = false

  for (const item of items) {
    const isProduct = item?.sectionType === 'product' || /^\d+\.\s+/.test(String(item?.text || ''))

    if (isProduct) {
      seenProduct = true
      continue
    }

    if (!seenProduct) before.push(item)
    else after.push(item)
  }

  if (!before.length) {
    before.push({ type: 'h2', sectionType: 'intro', text: 'Introduction' })
  }

  return [...before, ...productItems, ...after]
}

export async function generateAmazonRoundupOutline(body, genAI) {
  const { settings } = body
  let { targetKeyword } = body
  const { model, language, country, includeFaq, automaticExternalLinks } = settings
  const sourceArticleText = String(body.sourceArticleText || '').trim()
  const isRewriteMode = Boolean(sourceArticleText) || settings.type === 'amazon-roundup-rewrite'

  if (isRewriteMode) targetKeyword = cleanRewriteKeyword(targetKeyword) || targetKeyword || ''

  let formattedProducts = Array.isArray(body.prefetchedProducts)
    ? body.prefetchedProducts.filter(p => p && (p.productName || p.asin || p.amazonUrl))
    : []

  if (!formattedProducts.length) {
    const amazonApiData = await fetchInternalAmazonData(targetKeyword, settings)

    formattedProducts = formatAmazonProducts(amazonApiData, settings)
  }

  if (isRewriteMode) {
    formattedProducts = await fillRoundupProducts(formattedProducts, settings, targetKeyword)
  }

  if (formattedProducts.length === 0) {
    throw new Error('No Amazon products found for this keyword. Please check the keyword, ASINs, or Amazon API limit.')
  }

  const langObj = languages ? languages[language] : null
  const langName = langObj ? langObj.name : language || 'English'
  const countryObj = countries ? countries.find(c => c.code === country) : null
  const countryName = countryObj ? countryObj.name : country || 'United States'

  const baseSystemInstruction = getBaseSystemInstruction(langName, countryName)

  const productListString = formattedProducts
    .map(
      (p, index) =>
        `${index + 1}. ${p.productName}\n   URL: ${p.amazonUrl}\n   Image: ${p.imageUrl}\n   Price: ${p.price}`
    )
    .join('\n\n')

  let fetchedExternalLinks = []
  let faqInstruction = ''
  let relatedInstruction = ''

  if (automaticExternalLinks || includeFaq) {
    const outlineData = await fetchSerperOutlineData(targetKeyword, {
      strictProduct: settings.type === 'amazon-roundup-rewrite'
    })

    if (automaticExternalLinks) {
      fetchedExternalLinks = outlineData.authorityLinks
    }

    if (includeFaq) {
      if (outlineData.faqs.length > 0) {
        faqInstruction = `\nCRITICAL REQUIREMENT - FAQ SECTION: You MUST include an H2 heading titled exactly "Frequently Asked Questions". Under this H2, you MUST nest exactly these questions directly from Google as H3 subheadings:\n${outlineData.faqs
          .slice(0, 5)
          .map(q => `- ${q}`)
          .join('\n')}`
      } else {
        faqInstruction = `\nCRITICAL REQUIREMENT - FAQ SECTION: You MUST include an H2 heading titled "Frequently Asked Questions" and nest 3-5 highly relevant questions as H3 subheadings.`
      }
    }

    if (outlineData.related.length > 0) {
      relatedInstruction = `\nSEO OPTIMIZATION: Naturally incorporate topics from these related Google searches into your H2 and H3 headings where relevant: ${outlineData.related.slice(0, 5).join(', ')}.`
    }
  }

  const outlineModel = genAI.getGenerativeModel({
    model: model || 'gemini-3.1-flash-lite',
    generationConfig: { responseMimeType: 'application/json' },
    systemInstruction: `${baseSystemInstruction}\n\nSPECIAL INSTRUCTION: Generate a highly engaging Amazon Roundup article outline for the keyword: "${targetKeyword}". You MUST return a JSON object with four keys: "metaTitle" (SEO title, max 60 chars), "metaDescription" (SEO desc, max 160 chars), "title" (A catchy H1 Title) and "outline" (A flat JSON array of objects).\n\nFor standard sections (intro, buying_guide, faq), use this schema:\n{ "type": "h2", "text": "Section Title", "sectionType": "intro" }\n\nFor "product" sections, you MUST include the rich product data provided to you using this schema:\n{\n  "type": "h2",\n  "text": "[Product Name]",\n  "sectionType": "product",\n  "productData": {\n    "productName": "Exact Amazon Title",\n    "amazonUrl": "https://amazon.com/dp/...",\n    "imageUrl": "https://m.media-amazon.com/images/...",\n    "price": "$19.99"\n  }\n}\n\nCRITICAL OUTLINE RULES:\n- The "title" MUST contain the exact target keyword: "${targetKeyword}".\n- The VERY FIRST "h2" object (intro) MUST contain the exact target keyword: "${targetKeyword}" in its "text" field.\n- The VERY LAST "h2" object (conclusion or faq) MUST contain the exact target keyword: "${targetKeyword}" in its "text" field.`
  })

  const outlinePrompt = `
    CRITICAL STRUCTURE & SCHEMA REQUIREMENTS:
    You must format the outline array exactly like this to support the frontend editor:
    Schema: { "type": "h2", "text": "Heading Text", "sectionType": "the_type" }

    Rules for "type": MUST strictly be "h2" or "h3".
    Rules for "text": The actual string of the heading.
    Rules for "sectionType": MUST be one of: "intro", "product", "buying_guide", "conclusion", or "faq".

    LAYOUT ORDER:
    1. The first item MUST be an "intro" (type: h2).
    2. Next, you MUST create a "product" (type: h2) for EXACTLY these products using this precise data. You MUST explicitly number the product titles in the "text" field (e.g., "1. Product Name", "2. Product Name"):
    ${productListString}
    3. Include a "buying_guide" (type: h2) after the product reviews.
    4. Include a "conclusion" (type: h2).
    5. ${faqInstruction}
    6. ${relatedInstruction}

    ${
      isRewriteMode && sourceArticleText
        ? `REWRITE MODE (Amazon Roundup layout — same as native Amazon Roundup):
    - Source article text is reference only. Rewrite in a fresh voice; do not copy sentences.
    - The selected Number of Products is ${formattedProducts.length}. Output EXACTLY that many product H2s, even if the source article lists a different count.
    - Prefer ASINs, names, and details from the source when they appear in the product list. Extra products may come from a fresh Amazon search.
    - Keep the EXACT layout order above (intro → numbered products → buying_guide → conclusion → optional FAQ).
    - Each product H2 MUST keep sectionType "product" and include productData (productName, amazonUrl, imageUrl, price) from the list.
    - Do not turn this into a generic blog outline.

    SOURCE ARTICLE (reference):
    ${sourceArticleText.substring(0, 120000)}`
        : ''
    }
  `

  let parsedData = null
  let lastOutlineError = null

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const result = await outlineModel.generateContent(outlinePrompt)
      const raw = result.response.text()

      parsedData = JSON.parse(raw)

      if (!parsedData?.outline || !Array.isArray(parsedData.outline) || parsedData.outline.length === 0) {
        throw new Error('Outline JSON missing outline array')
      }

      break
    } catch (err) {
      lastOutlineError = err
      const msg = String(err?.message || err)

      const isCapacity =
        /429|rate.?limit|quota|resource.?exhausted|503|high demand|unavailable|overloaded|try again later/i.test(msg)

      if (isCapacity) {
        console.warn('[Outline] Gemini quota/high demand — using Groq/Mistral')

        const alt = await callLightLLM({
          system: 'Return only valid JSON with keys metaTitle, metaDescription, title, outline. No markdown.',
          prompt:
            outlinePrompt +
            '\n\nReturn JSON: {"metaTitle":"","metaDescription":"","title":"","outline":[{"type":"h2","text":"","sectionType":"intro"}]}',
          json: true,
          max_tokens: 1600
        })

        const parsed = parseJsonSafe(alt?.text)

        if (parsed?.outline?.length) {
          parsedData = parsed
          break
        }

        throw new Error('RATE_LIMIT: Gemini and Groq could not produce an outline. Wait ~60s and try again.')
      }

      if (attempt < 3) {
        await new Promise(r => setTimeout(r, 800 * attempt))
        continue
      }

      throw new Error(`OUTLINE_PARSE_FAILED: Could not produce a valid outline after ${attempt} attempts. ${msg}`)
    }
  }

  if (!parsedData) {
    throw lastOutlineError || new Error('OUTLINE_PARSE_FAILED')
  }

  const [unsplashRes, pexelsRes, pixabayRes] = await Promise.all([
    fetchUnsplashImage(targetKeyword),
    fetchPexelsImage(targetKeyword),
    fetchPixabayImage(targetKeyword)
  ])

  let candidates = [...unsplashRes, ...pexelsRes, ...pixabayRes].filter(img => img && img.url)
  let heroImageUrl = ''
  let heroImageId = null
  let heroImageSource = null
  let fallbackToAiImageTag = false
  let scoredCandidates = []

  if (candidates.length > 0) {
    scoredCandidates = candidates.map(c => ({
      ...c,
      score: calculateRelevanceScore(c.alt || '', targetKeyword, targetKeyword)
    }))

    scoredCandidates.sort((a, b) => b.score - a.score)

    const heroPick = isRewriteMode && scoredCandidates.length > 1 ? scoredCandidates[1] : scoredCandidates[0]

    if (heroPick && heroPick.score >= 2.0) {
      heroImageUrl = heroPick.url
      heroImageId = heroPick.id ?? null
      heroImageSource = heroPick.source || null
      console.log(`[Hero Image] Selected ${heroPick.source} (Score: ${heroPick.score})`)
    } else {
      console.log(
        `[Hero Image] Top image score (${scoredCandidates[0].score}) below 2.0. Invoking AI generation logic.`
      )
      fallbackToAiImageTag = true
    }
  } else {
    fallbackToAiImageTag = true
  }

  if (fallbackToAiImageTag) {
    const safetyBackup = scoredCandidates.length > 0 ? scoredCandidates[0].url : ''

    try {
      const fallbackImage = await generateFallbackImage(`High quality, realistic photograph of ${targetKeyword}`)

      if (fallbackImage && fallbackImage.url) {
        heroImageUrl = fallbackImage.url
      }
    } catch (error) {
      heroImageUrl = safetyBackup
      console.log(`[Hero Image] AI Fallback failed to generate a URL.`)
    }

    console.log(`[Hero Image] AI Generation Result: ${heroImageUrl ? 'Success' : 'Failed - Using Safety Backup'}`)
  }

  if (Array.isArray(parsedData.outline)) {
    let productCursor = 0

    parsedData.outline = parsedData.outline.map(item => {
      if (!item || typeof item !== 'object') return item
      const next = { ...item, text: typeof item.text === 'string' ? titleCaseWords(item.text) : item.text }

      const isProduct = next.sectionType === 'product' || /^\d+\.\s+/.test(String(next.text || ''))

      if (isProduct && formattedProducts[productCursor]) {
        const product = formattedProducts[productCursor]

        productCursor += 1
        next.sectionType = 'product'
        next.productData = outlineProductData(product)

        if (product.productName && !/^\d+\.\s+/.test(String(next.text || ''))) {
          next.text = titleCaseWords(`${productCursor}. ${product.productName}`)
        }
      }

      return next
    })

    if (isRewriteMode) {
      parsedData.outline = applyExactProductOutline(parsedData.outline, formattedProducts)
    }
  }

  if (!isRewriteMode && formattedProducts.some(p => p.imageUrl)) {
    const productHero = formattedProducts.find(p => p.imageUrl)?.imageUrl || ''

    if (productHero) {
      heroImageUrl = productHero
      heroImageId = null
      heroImageSource = 'amazon'
    }
  }

  return {
    success: true,
    title: parsedData.title,
    outline: parsedData.outline,
    metaTitle: parsedData.metaTitle,
    metaDescription: parsedData.metaDescription,
    externalLinks: fetchedExternalLinks,
    heroImage: heroImageUrl,
    heroImageId,
    heroImageSource,
    productImages: formattedProducts.map(p => p.imageUrl).filter(Boolean),
    rewriteProducts: formattedProducts
  }
}

export async function generateAmazonRoundupSection(body, genAI) {
  const {
    heading,
    text,
    section = {},
    articleTitle,
    outlineContext,
    settings = {},
    targetKeyword,
    internalLinks,
    externalLinks,
    usedExternalLinks = [],
    usedInternalLinks = []
  } = body

  const { model, enableFirstHandExperience, improveReadability, pointOfView, toneOfVoice, customToneOfVoice } = settings

  const outlineProducts = (Array.isArray(outlineContext) ? outlineContext : [])
    .map(item => item?.productData)
    .filter(product => product && (product.imageUrl || product.asin || product.productName || product.amazonUrl))

  let formattedProducts =
    Array.isArray(body.prefetchedProducts) && body.prefetchedProducts.length ? body.prefetchedProducts : outlineProducts

  if (!formattedProducts.length) {
    const amazonApiData =
      body.shared?.amazon || (await fetchInternalAmazonData(targetKeyword || articleTitle, settings))

    formattedProducts = formatAmazonProducts(amazonApiData, settings)
  }

  const sourceArticleText = String(body.sourceArticleText || settings.fetchedSourceArticle || '').trim()

  const activeHeadingText = heading || text || section.text || section.heading || 'Section'
  let activeSectionType = section.sectionType || section.type

  if (!activeSectionType && Array.isArray(outlineContext)) {
    const matchedSection = outlineContext.find(s => s.text === activeHeadingText || activeHeadingText.includes(s.text))

    if (matchedSection) {
      activeSectionType = matchedSection.sectionType
    }
  }

  activeSectionType = activeSectionType || 'standard'

  const sectionModel = genAI.getGenerativeModel({ model: model || 'gemini-3.1-flash-lite' })

  const toneInstruction = getToneInstruction(toneOfVoice, customToneOfVoice)
  const povInstruction = getPovInstruction(pointOfView)
  const readabilityInstruction = getReadabilityInstruction(improveReadability)
  const seoInstruction = await getSeoInstruction(targetKeyword)

  let { instruction: linkInstruction, selectedUrl: internalLinkUrl } = await getLinkInstruction(
    internalLinks,
    heading,
    genAI,
    usedInternalLinks
  )
  let extLinkInstruction = ''

  if (activeSectionType === 'intro' || activeSectionType === 'buying_guide') {
    extLinkInstruction = settings.automaticExternalLinks
      ? getExternalLinkInstruction(externalLinks, usedExternalLinks)
      : '\nCRITICAL FORMATTING: Do NOT include or generate any external URLs or links in this section under any circumstances.'
  }

  const experienceInstruction = enableFirstHandExperience
    ? "CRITICAL: Write this review using strong first-hand experience. Use phrases like 'When I tested this...', 'In my hands-on experience...', and 'What I noticed right away...'. Speak as an expert who has physically unboxed and used the item."
    : 'Write this review from an objective, expert standpoint based on specifications, features, and market consensus.'

  const activeSEOKeyword = targetKeyword || articleTitle || heading
  const lsiData = await fetchPeopleAlsoSearchFor(activeSEOKeyword)
  const lsiString = `Google Keywords: [${lsiData.google.join(', ')}]. Bing Keywords: [${lsiData.bing.join(', ')}].`

  const keywordSEOInstructions = `
    CRITICAL SEO & FORMATTING REQUIREMENTS:
    - Target Keyword: "${activeSEOKeyword}"
    - LSI / Related Keywords: [${lsiString}]

    1. KEYWORD PLACEMENT & BOLDING: You MUST use the exact Target Keyword multiple times naturally throughout this section to ensure strong topic relevance. If this section is the Introduction or Conclusion, this is absolutely MANDATORY. Format the target keyword in bold (**${activeSEOKeyword}**) every time it is used.
    2. LSI INTEGRATION: You MUST naturally integrate 1 to 2 of the provided LSI keywords into the paragraphs or subheadings of this section. CRITICAL: Use each LSI keyword a MAXIMUM of 1 or 2 times to avoid keyword stuffing. Ensure the main Target Keyword is used more frequently than any single LSI keyword.
    3. LSI BOLDING: Every time you use an LSI keyword, you MUST format it in bold (e.g., **LSI keyword**).
    4. LIST FORMATTING: If you use bullet points or ordered list items anywhere in this section, each individual list item MUST be 2 to 3 sentences long to provide detailed value. Do NOT write single-sentence or one-liner list items.
  `

  let topPicksTable = ''
  let matchedProduct = null

  let sectionPrompt = `
    Article Title Context: ${articleTitle || targetKeyword}
    Full Article Outline Context: ${JSON.stringify(outlineContext)}
    Current Heading: ${activeHeadingText}

    ${seoInstruction}
    ${toneInstruction}
    ${povInstruction}
    ${readabilityInstruction}
    ${linkInstruction}
    ${extLinkInstruction}
    ${keywordSEOInstructions}
    ${
      sourceArticleText
        ? `REWRITE SOURCE (reference only — rewrite freshly, same Amazon Roundup layout rules):
${sourceArticleText.substring(0, 80000)}`
        : ''
    }
  `

  if (activeSectionType === 'intro') {
    const top3 = formattedProducts.slice(0, 3)

    const linkOptions = {
      language: settings.language,
      domain: settings.amazonDomain || 'www.amazon.com',
      partnerTag: settings.amazonTrackingId || process.env.AMAZON_PARTNER_TAG || ''
    }

    topPicksTable =
      settings.roundupLayout === 'top-pick'
        ? renderTopPickCards(formattedProducts, linkOptions)
        : renderResponsiveTable({
            headers: ['Image', 'Product', 'Link'],
            rows: top3.map(p => {
              const safeTitle = escapeHtml(String(p.productName || '').replace(/[\r\n]+/g, ' '))
              const safeImageUrl = escapeHtml(toHdAmazonImage(p.imageUrl))
              const altText = escapeHtml(`${targetKeyword || ''} ${p.productName || ''}`.trim())
              const button = buildCheckPriceButton(p.amazonUrl, { ...linkOptions, asin: p.asin })

              return [
                `<img src="${safeImageUrl}" alt="${altText}" title="${safeTitle}" style="width:80px;height:80px;max-width:100%;object-fit:contain;border-radius:8px;" />`,
                safeTitle,
                button
              ]
            })
          })

    sectionPrompt +=
      settings.roundupLayout === 'top-pick'
        ? `TASK: Write an engaging introduction for "${targetKeyword}". Do NOT output a product table, product cards, product images, or Check Price buttons. The ranked Top Pick cards are inserted after your paragraphs.`
        : `TASK: Write a strong, engaging introduction for the keyword "${targetKeyword}". Immediately following your introductory paragraphs, include this Product Table:\n### Our Top 3 Products\n${topPicksTable}`
  } else if (activeSectionType === 'product') {
    const cleanHeading = activeHeadingText
      .replace(/^\d+\.\s*/, '')
      .toLowerCase()
      .trim()

    const product =
      formattedProducts.find(p => {
        const pName = p.productName.toLowerCase()

        return cleanHeading.includes(pName) || pName.includes(cleanHeading)
      }) || formattedProducts[0]

    matchedProduct = product

    sectionPrompt += `
      TASK: Write a comprehensive product review for "${product.productName}".
      CRITICAL: Start writing directly from the review body paragraphs. Do NOT output any H1/H2/H3 heading or repeat the product title/heading text at the start — the editor already renders the heading.
      Do NOT invent a second "Final Thoughts" or duplicate section title.
      ${experienceInstruction}

      PRODUCT CONTEXT (DO NOT INVENT PRICING):
      - Title: ${product.productName}
      - Price: ${product.price}

      STRICT LAYOUT REQUIREMENT:
      Format this section EXACTLY in this order:
      1. **Review:** 2-3 engaging paragraphs reviewing the product.
      2. **HTML Image:** Insert this EXACT HTML centered:
         <div align="center" style="margin: 25px 0;">
            <img src="${toHdAmazonImage(product.imageUrl)}" alt="${targetKeyword} ${product.productName}" title="${product.productName}" data-product-shot="1" style="display:block;max-width:min(100%,480px);width:auto;height:auto;max-height:640px;margin:0 auto;object-fit:contain;aspect-ratio:auto;background:#ffffff;border-radius:12px;box-shadow:0 4px 10px rgba(0,0,0,0.06);" />
          </div>
      3. **Features:** A bulleted list of 3-4 key features.
      4. **Pros & Cons Table:** A strictly formatted Markdown table with exactly two columns titled "Pros" and "Cons".
      5. **Real Buyer Opinions:** A brief summary of what real buyers think. CRITICAL: You must synthesize this summary directly from the "Official Features" provided above. Frame the feedback around how buyers react to those specific attributes (e.g., if a feature highlights 'lightweight design', mention how users praise its portability).
      6. **CTA Button:** Insert this EXACT HTML. Do not change the link or the label:
         <div class="affigenie-cta" style="display:block;width:100%;max-width:100%;text-align:center;margin:25px 0;">
           ${buildCheckPriceButton(product.amazonUrl, {
             language: settings.language,
             asin: product.asin,
             domain: settings.amazonDomain || 'www.amazon.com',
             partnerTag: settings.amazonTrackingId || process.env.AMAZON_PARTNER_TAG || ''
           })}
         </div>
    `
  } else if (activeSectionType === 'faq') {
    sectionPrompt += `
      TASK: Write a comprehensive FAQ section containing 4 to 6 commonly asked questions regarding "${targetKeyword}".

      STRICT REQUIREMENT (Schema Markup):
      You MUST wrap the questions and answers in valid JSON-LD FAQPage schema markup. Place the schema inside a <script type="application/ld+json"> tag at the very end of the section. Do NOT use markdown code blocks around the script tag.
    `
  } else {
    sectionPrompt += `
      TASK: Write a comprehensive section for "${activeHeadingText}".
      CRITICAL: Do NOT repeat the heading text as an H2/H3 inside the body. Start with paragraphs only.
      Keep formatting clean and avoid duplicating titles that already exist in the outline.
    `
  }

  let result = null

  try {
    result = await sectionModel.generateContent(sectionPrompt)
  } catch (error) {
    const msg = (error?.message || String(error) || '').toLowerCase()

    const shouldFallback =
      /429|quota|rate.?limit|resource.?exhausted|503|high demand|unavailable|overloaded|try again later|fetch failed/i.test(
        msg
      )

    if (!shouldFallback) throw error

    console.warn('[Section] Gemini quota hit — writing this section with Groq/Mistral')

    const alt = await callLightLLM({
      system: 'You are an expert SEO article writer. Return only the section body in markdown. No preamble, no JSON.',
      prompt: sectionPrompt.slice(0, 6000),
      max_tokens: 1400,
      waitOn429: false
    })

    if (!alt?.text) {
      console.error('[Section] All providers exhausted. Skipping this heading.')

      return {
        success: false,
        skipped: true,
        heading,
        error: 'RATE_LIMIT',
        message: 'Gemini, Groq, and Mistral are all rate-limited. Wait ~60s and regenerate this section.'
      }
    }

    result = { response: { text: () => alt.text } }
  }

  let sectionText = result.response.text()

  if (activeSectionType === 'intro' && typeof topPicksTable === 'string' && topPicksTable) {
    if (settings.roundupLayout === 'top-pick') {
      sectionText = sectionText
        .replace(/<div\b[^>]*affigenie-product-cards[\s\S]*$/i, '')
        .replace(/<article\b[^>]*affigenie-product-card[\s\S]*?<\/article>/gi, '')
        .replace(/<h2\b[^>]*affigenie-top-pick[\s\S]*?<\/h2>/gi, '')
        .replace(/<table\b[\s\S]*?<\/table>/gi, '')
        .trim()
      sectionText = `${sectionText}\n\n${topPicksTable}`
    } else if (!/<table[\s>]/i.test(sectionText)) {
      sectionText += `\n\n${topPicksTable}`
    }
  }

  if (activeSectionType === 'product' && matchedProduct) {
    const shot = toHdAmazonImage(matchedProduct.imageUrl)

    if (shot && !sectionText.includes(shot) && !sectionText.includes(String(matchedProduct.imageUrl || ''))) {
      const alt = escapeHtml(`${targetKeyword || ''} ${matchedProduct.productName || ''}`.trim())

      sectionText += `\n\n<img src="${escapeHtml(shot)}" alt="${alt}" />`
    }

    if (matchedProduct.amazonUrl || matchedProduct.asin) {
      sectionText = withRequiredCheckPrice(sectionText, {
        url: matchedProduct.amazonUrl,
        asin: matchedProduct.asin,
        language: settings.language,
        domain: settings.amazonDomain || 'www.amazon.com',
        partnerTag: settings.amazonTrackingId || process.env.AMAZON_PARTNER_TAG || ''
      })
    }
  }

  return { success: true, text: sectionText, mediaHtml: null, internalLinkUrl: internalLinkUrl }
}
