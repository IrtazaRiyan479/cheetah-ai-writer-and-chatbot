import { AsyncLocalStorage } from 'node:async_hooks'

import { serializeError } from '@/utils/serializeError'

const keyTierStore = new AsyncLocalStorage()

export function runWithPaidKeys(paid, fn) {
  return keyTierStore.run({ paid: Boolean(paid) }, fn)
}

/** Explicit true/false wins. An active request tier wins over model-name guesses. */
export function resolvePaidTier(explicit, model) {
  if (typeof explicit === 'boolean') return explicit
  const store = keyTierStore.getStore()
  if (store && typeof store.paid === 'boolean') return store.paid
  return /(?:-pro(?:-|$)|-image(?:-|$)|-pro-image)/i.test(String(model || ''))
}

export function parseProviderKeyList(value) {
  const values = String(value || '').split(/[\n,;]+/)
  const seen = new Set()

  return values.map(value => value.trim()).filter(value => {
    if (!value || seen.has(value)) return false
    seen.add(value)
    return true
  })
}

export function listProviderKeys(primaryListName, { numberedPrefix, legacySingles = [] } = {}) {
  const values = [process.env[primaryListName] || '']
  if (numberedPrefix) {
    for (let index = 1; index <= 20; index++) values.push(process.env[`${numberedPrefix}${index}`] || '')
  }
  for (const name of legacySingles) values.push(process.env[name] || '')
  return parseProviderKeyList(values.join('\n'))
}

function failureCode(error) {
  return String(error?.status || error?.statusCode || serializeError(error).match(/(?:HTTP\s*)?(\d{3})/i)?.[1] || 'error')
}

export async function withProviderKey(keys, fn, label = 'provider') {
  const ordered = [...new Set((keys || []).map(value => String(value || '').trim()).filter(Boolean))]
  if (!ordered.length) return null
  let lastError

  for (let index = 0; index < ordered.length; index++) {
    try {
      const result = await fn(ordered[index], { index, total: ordered.length })
      if (result == null || result === '') throw new Error('Provider returned an empty response.')
      return result
    } catch (error) {
      lastError = error
      const snippet = serializeError(error).replace(/\s+/g, ' ').slice(0, 180)
      console.warn(`[${label}] key ${index + 1}/${ordered.length} failed status=${failureCode(error)} msg="${snippet}"`)
    }
  }

  throw new Error(serializeError(lastError))
}
