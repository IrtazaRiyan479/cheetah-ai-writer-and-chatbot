'use client'

import { useState, useEffect } from 'react'

import { useRouter } from 'next/navigation'

import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import CardActions from '@mui/material/CardActions'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import Dialog from '@mui/material/Dialog'
import DialogTitle from '@mui/material/DialogTitle'
import DialogContent from '@mui/material/DialogContent'
import DialogActions from '@mui/material/DialogActions'
import Grid from '@mui/material/Grid'
import Chip from '@mui/material/Chip'
import IconButton from '@mui/material/IconButton'
import Skeleton from '@mui/material/Skeleton'
import Box from '@mui/material/Box'

import ModuleGate from '@/components/access/ModuleGate'
import { extractStoredOutline, stripOutlineField } from '@/app/api/generate/utils/articleHtml'

const extractPreview = htmlContent => {
  const visible = stripOutlineField(htmlContent)

  if (!visible) return { img: null, desc: '' }

  const imgMatch = visible.match(/<img[^>]+src=["']([^"']+)["']/i)
  const img = imgMatch ? imgMatch[1] : null

  let desc = ''
  const pMatches = visible.match(/<p>([\s\S]*?)<\/p>/gi)

  if (pMatches) {
    desc = pMatches
      .map(p => p.replace(/<[^>]+>/g, '').trim())
      .filter(t => t.length > 0 && !/^affigenie-outline:/i.test(t))
      .join(' ')
  } else {
    desc = visible
      .replace(/<[^>]+>/g, ' ')
      .replace(/affigenie-outline:[A-Za-z0-9+/=]+/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim()
  }

  if (desc.length > 420) {
    desc = desc.substring(0, 400) + '...'
  }

  return { img, desc }
}

const readOutlineMeta = article => {
  if (article?.status !== 'outline' || !article.outline) return null

  try {
    const parsed = JSON.parse(article.outline)

    if (!parsed?.review || !Array.isArray(parsed.outline)) return null

    const headings = parsed.outline
      .map(item => item?.text)
      .filter(Boolean)
      .slice(0, 4)
      .join(' · ')

    const heroImage =
      parsed.heroImage ||
      parsed.image ||
      parsed.featuredImage ||
      parsed.settings?.heroImage ||
      parsed.settings?.youtubeThumbnail ||
      ''

    return {
      img: heroImage,
      desc: headings || 'Outline is ready. Open it, review the headings, then click Write Article.'
    }
  } catch {
    return null
  }
}

const writerHref = query => {
  const segment = window.location.pathname.split('/').filter(Boolean)[0]
  const lang = ['en', 'fr', 'ar'].includes(segment) ? segment : 'en'

  return `/${lang}/writer?${query}`
}

export default function DraftsPage() {
  const [articles, setArticles] = useState([])
  const [loading, setLoading] = useState(true)
  const [loginDialogOpen, setLoginDialogOpen] = useState(false)
  const router = useRouter()

  const fetchArticles = async () => {
    try {
      const res = await fetch('/api/drafts')

      if (res.status === 401) {
        setLoginDialogOpen(true)
        setLoading(false)

        return
      }

      const data = await res.json()

      if (data.articles) {
        setArticles(data.articles)
      }
    } catch (error) {
      console.error('Failed to load drafts', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchArticles()
  }, [])

  const handleDelete = async id => {
    if (!confirm('Are you sure you want to delete this draft?')) return

    try {
      const res = await fetch(`/api/drafts?id=${id}`, {
        method: 'DELETE'
      })

      const data = await res.json()

      if (data.success) {
        setArticles(articles.filter(article => article.id !== id))
      } else {
        alert('Failed to delete draft')
      }
    } catch (error) {
      console.error(error)
    }
  }

  const handleEdit = article => {
    const outlineMeta = readOutlineMeta(article)
    const query = outlineMeta ? `outlineId=${article.id}` : `draftId=${article.id}`

    router.push(writerHref(query))
  }

  return (
    <ModuleGate featureKey='module-drafts'>
      <div className='w-full p-6'>
        <div className='flex justify-between items-center mb-8'>
          <Typography variant='h4' className='font-bold'>
            My Drafts
          </Typography>
          <Button
            variant='contained'
            color='primary'
            onClick={() => router.push('/writer')}
            startIcon={<i className='ri-add-line' />}
          >
            New Article
          </Button>
        </div>

        {loading ? (
          <Grid container spacing={4}>
            {[1, 2, 3].map(n => (
              <Grid size={12} key={n}>
                <Card className='shadow-md rounded-xl h-full flex flex-col'>
                  <Skeleton variant='rectangular' height={140} />
                  <CardContent className='flex-grow'>
                    <Skeleton variant='text' height={40} />
                    <Skeleton variant='text' width='60%' />
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        ) : articles.length === 0 ? (
          <Box className='flex flex-col items-center justify-center p-12 text-center border-2 border-dashed border-gray-300 rounded-xl bg-gray-50'>
            <i className='ri-draft-line text-6xl text-gray-400 mb-4' />
            <Typography variant='h5' className='font-semibold text-gray-600 mb-2'>
              No drafts found
            </Typography>
            <Typography variant='body1' className='text-gray-500 mb-6 max-w-md'>
              Looks like you haven't saved any drafts yet. Start writing your next great article!
            </Typography>
            <Button variant='contained' color='primary' onClick={() => router.push('/writer')}>
              Create Your First Draft
            </Button>
          </Box>
        ) : (
          <Grid container spacing={4}>
            {articles.map(article => {
              const outlineMeta = readOutlineMeta(article)
              const hidden = extractStoredOutline(article.content)
              let columnHero = ''

              try {
                const parsed = article.outline ? JSON.parse(article.outline) : null

                columnHero = parsed?.heroImage || parsed?.settings?.heroImage || parsed?.image || ''
              } catch {
                columnHero = ''
              }

              const { img, desc } = extractPreview(article.content)
              const cardImg = outlineMeta?.img || columnHero || hidden?.heroImage || img

              const preview = outlineMeta ? outlineMeta.desc : desc

              return (
                <Grid size={12} key={article.id}>
                  <Card className='shadow-md rounded-xl hover:shadow-lg transition-shadow duration-300 flex flex-col h-full border border-gray-100 overflow-hidden'>
                    {/* Hero Image Section */}
                    {cardImg ? (
                      <Box
                        className={`w-full bg-cover bg-center border-b border-gray-100 ${outlineMeta ? 'h-96' : 'h-80'}`}
                        style={{ backgroundImage: `url(${cardImg})`, width: '100%' }}
                      />
                    ) : (
                      <Box className='w-full h-40 bg-gray-50 flex items-center justify-center border-b border-gray-100'>
                        <i className='ri-image-line text-4xl text-gray-300'></i>
                      </Box>
                    )}

                    <CardContent className='flex-grow flex flex-col gap-3 p-5'>
                      <div className='flex justify-between items-start'>
                        <Chip
                          label={outlineMeta ? 'OUTLINE' : article.status.toUpperCase()}
                          size='small'
                          color={outlineMeta ? 'info' : article.status === 'draft' ? 'warning' : 'success'}
                          className='font-medium text-xs'
                        />
                        {article.targetSite && (
                          <Chip label={article.targetSite} size='small' variant='outlined' className='text-xs' />
                        )}
                      </div>
                      <Typography variant='h6' className='font-bold line-clamp-2 mt-1 leading-tight'>
                        {article.title || 'Untitled Draft'}
                      </Typography>

                      <Typography variant='body2' color='textSecondary' className='line-clamp-3 mb-2 min-h-[60px]'>
                        {preview || 'No description available for this draft.'}
                      </Typography>

                      <Typography
                        variant='caption'
                        color='textSecondary'
                        className='flex items-center gap-1 mt-auto pt-3 border-t border-gray-100'
                      >
                        <i className='ri-calendar-line' />
                        Last saved:{' '}
                        {new Date(article.createdAt).toLocaleDateString(undefined, {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        })}
                      </Typography>
                    </CardContent>
                    <CardActions className='flex justify-between border-t border-gray-100 p-4 bg-gray-50/50'>
                      <Button
                        size='small'
                        variant='outlined'
                        color='primary'
                        onClick={() => handleEdit(article)}
                        startIcon={<i className='ri-edit-line' />}
                      >
                        {outlineMeta ? 'Review outline' : 'Continue Editing'}
                      </Button>
                      <IconButton
                        size='small'
                        color='error'
                        onClick={() => handleDelete(article.id)}
                        title='Delete Draft'
                      >
                        <i className='ri-delete-bin-line' />
                      </IconButton>
                    </CardActions>
                  </Card>
                </Grid>
              )
            })}
          </Grid>
        )}

        {/* Login Required Dialog */}
        <Dialog open={loginDialogOpen} onClose={() => setLoginDialogOpen(false)} maxWidth='xs' fullWidth>
          <DialogTitle className='flex items-center gap-2 text-error'>
            <i className='ri-error-warning-line text-xl text-red-500' /> Session Expired
          </DialogTitle>
          <DialogContent>
            <Typography>
              You need to be logged in to view or manage your drafts. Please log in to continue without losing your
              progress.
            </Typography>
          </DialogContent>
          <DialogActions className='p-4'>
            <Button onClick={() => setLoginDialogOpen(false)} color='inherit'>
              Dismiss
            </Button>
            <Button variant='contained' color='primary' onClick={() => router.push('/login')}>
              Go to Login
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    </ModuleGate>
  )
}
