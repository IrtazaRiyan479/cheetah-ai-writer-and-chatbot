'use client'

// MUI Imports
import Grid from '@mui/material/Grid'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import Chip from '@mui/material/Chip'
import TextField from '@mui/material/TextField'
import IconButton from '@mui/material/IconButton'

// Third-party Imports
import classnames from 'classnames'

// Component Imports
import Link from '@components/Link'
import Logo from '@components/layout/shared/Logo'

// Util Imports
import { frontLayoutClasses } from '@layouts/utils/layoutClasses'

// Styles Imports
import styles from './styles.module.css'
import frontCommonStyles from '@views/apps/styles.module.css'

import CircularProgress from '@mui/material/CircularProgress'
import { useState } from 'react'

const Footer = () => {

  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('idle');

  const handleSubscribe = async (e) => {
    if (e) e.preventDefault();
    if (!email) return;

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setStatus('invalid');
      setTimeout(() => setStatus('idle'), 4000);
      return;
    }
    setStatus('loading');

    try {
      const res = await fetch('/api/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      if (res.ok) {
        setStatus('success');
        setEmail('');
        setTimeout(() => setStatus('idle'), 4000);
      } else {
        setStatus('error');
        setTimeout(() => setStatus('idle'), 4000);
      }
    } catch (error) {
      setStatus('error');
      setTimeout(() => setStatus('idle'), 4000);
    }
  };

  return (
    <footer className={frontLayoutClasses.footer}>
      <div className='relative'>
        <img
          src='/images/front-pages/footer-bg.png'
          alt='footer bg'
          className='absolute inset-0 is-full bs-full object-cover -z-[1]'
        />
        <div className={classnames('plb-12 text-white', frontCommonStyles.layoutSpacing)}>
          <Grid container rowSpacing={10} columnSpacing={12}>
            <Grid size={{ xs: 12, lg: 6 }}>
              <div className='flex flex-col items-start gap-6'>
                <Link href='/front-pages/landing-page'>
                  <Logo color='var(--mui-palette-common-white)' />
                </Link>
                <Typography color='white' className='lg:max-is-[390px] opacity-[0.78]'>
                  AffiGenie is your all in one platform for intelligent content generation, automated marketing, and custom chatbot development. Built for efficiency.
                </Typography>
                {/* --- RESTORED UI: Subscription Block --- */}
                <div>
                  <div className='flex gap-4'>
                    <TextField
                      size='small'
                      className={styles.inputBorder}
                      label='Subscribe to newsletter'
                      placeholder='Your email'
                      type='email'
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSubscribe(e)}
                      disabled={status === 'loading' || status === 'success'}
                      sx={{
                        ' & .MuiInputBase-root:hover:not(.Mui-focused) fieldset': {
                          borderColor: 'rgb(var(--mui-mainColorChannels-dark) / 0.6) !important'
                        },
                        '& .MuiInputBase-root.Mui-focused fieldset': {
                          borderColor: 'var(--mui-palette-primary-main)!important'
                        },
                        '& .MuiFormLabel-root.Mui-focused': {
                          color: 'var(--mui-palette-primary-main) !important'
                        }
                      }}
                    />
                    <Button
                      variant='contained'
                      color='primary'
                      onClick={handleSubscribe}
                      disabled={status === 'loading' || status === 'success'}
                      sx={{ minWidth: '110px' }} // Keeps button from shrinking when spinner shows
                    >
                      {status === 'loading' ? <CircularProgress size={24} color="inherit" /> : 'Subscribe'}
                    </Button>
                  </div>

                  {/* Feedback Messages */}
                  <div className='min-h-[20px] mbs-2'>
                    {status === 'success' && <Typography variant="caption" sx={{ color: '#4ade80' }}>✅ Subscribed successfully!</Typography>}
                    {status === 'error' && <Typography variant="caption" sx={{ color: '#f87171' }}>❌ Failed to subscribe. Please try again.</Typography>}
                    {status === 'invalid' && <Typography variant="caption" sx={{ color: '#f87171' }}>❌ Please enter a valid email address.</Typography>}
                  </div>
                </div>
              </div>
            </Grid>
            <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
              <Typography color='white' className='font-medium mbe-6 opacity-[0.92]'>
                Our Tools
              </Typography>
              <div className='flex flex-col gap-4'>
                <Typography component={Link} href='/chat' color='white' className='opacity-[0.78]'>
                  AffiGenie Chat
                </Typography>
                <Link href='/writer' className='flex items-center gap-[10px]'>
                  <Typography color='white' className='opacity-[0.78]'>
                    AffiGenie Writer
                  </Typography>
                  <Chip label='New' color='primary' size='small' />
                </Link>
                <Typography
                  component={Link}
                  href='/en/images'
                  color='white'
                  className='opacity-[0.78]'
                >
                  AffiGenie Images
                </Typography>
                <Typography component={Link} href='/en/links' color='white' className='opacity-[0.78]'>
                  AffiGenie Links
                </Typography>
                <Typography component={Link} href='/en/magnets' color='white' className='opacity-[0.78]'>
                  AffiGenie Magnets
                </Typography>
              </div>
            </Grid>
            <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
              <Typography color='white' className='font-medium mbe-6 opacity-[0.92]'>
                Account & Support
              </Typography>
              <div className='flex flex-col gap-4'>
                <Typography component={Link} href='/pricing' color='white' className='opacity-[0.78]'>
                  Pricing
                </Typography>
                <Typography component={Link} href='/contact' color='white' className='opacity-[0.78]'>
                  Contact
                </Typography>
                <Typography component={Link} href='/login' color='white' className='opacity-[0.78]'>
                  Login
                </Typography>
                <Typography component={Link} href='/register' color='white' className='opacity-[0.78]'>
                  Register
                </Typography>
                <Typography component={Link} href='/privacy-terms' color='white' className='opacity-[0.78]'>
                  Privacy & Terms
                </Typography>
              </div>
            </Grid>
          </Grid>
        </div>
      </div>
      <div className='bg-[#211B2C]'>
        <div
          className={classnames(
            'flex flex-wrap items-center justify-center sm:justify-between gap-4 plb-[15px]',
            frontCommonStyles.layoutSpacing
          )}
        >
          <Typography className='text-white opacity-[0.92]' variant='body2'>
            <span>{`© ${new Date().getFullYear()}, Made with `}</span>
            <span>{`❤️`}</span>
            <span>{` by `}</span>
            <Link href='https://www.linkedin.com/in/irtaza-riyan/' target='_blank' className='font-medium text-white'>
              Irtaza Riyan
            </Link>
          </Typography>
          <div className='flex gap-1.5 items-center opacity-[0.78]'>
            <IconButton component={Link} size='small' href='https://github.com/Irtaza Riyan' target='_blank'>
              <i className='ri-github-fill text-white text-lg' />
            </IconButton>
            <IconButton component={Link} size='small' href='https://www.facebook.com/Irtaza Riyans/' target='_blank'>
              <i className='ri-facebook-fill text-white text-lg' />
            </IconButton>
            <IconButton component={Link} size='small' href='https://twitter.com/Irtaza Riyans' target='_blank'>
              <i className='ri-twitter-fill text-white text-lg' />
            </IconButton>
            <IconButton component={Link} size='small' href='https://www.linkedin.com/company/Irtaza Riyan' target='_blank'>
              <i className='ri-linkedin-fill text-white text-lg' />
            </IconButton>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
